<?php 

if(session_status() == PHP_SESSION_NONE)
{
	session_start();
}

if(isset($_SESSION['accomodation'])){
?>

<!DOCTYPE html>
<html lang="">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Passagers</title>


    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-theme.min.css">

</head>

<body style="background-color: lightblue;">

    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Reservation de Billet en Ligne</a>
            </div>
            <ul class="nav navbar-nav">
                <li class="active">
                    <a href="#">Reservation
                        <span class="glyphicon glyphicon-share-alt" aria-hidden="true"></span>
                    </a>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="index.php"><span class="glyphicon glyphicon-backward"></span> Retour a l'Accueil</a></li>
            </ul>
        </div>
    </nav>


    <div class="container-fluid">
        <div class="col-md-1"></div>
        <div class="col-md-10">
            <div class="panel panel-danger">
                <div class="panel-heading">
                    <h3 class="panel-title">LES ETAPES DE LA RESERVATION</h3>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title">1. TRAJET
                                    </h3>
                                </div>
                                <div class="panel-body">
                                    PROGRAMME DE VOYAGE
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="panel panel-info">
                                <div class="panel-heading">
                                    <h3 class="panel-title">2.CATEGORIES DE BUS
                                    </h3>
                                </div>
                                <div class="panel-body">
                                    TYPES DE BUS
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="panel panel-success">
                                <div class="panel-heading">
                                    <h3 class="panel-title">3. INFOS DU PASSAGERS
                                        <span class="glyphicon glyphicon-saved" aria-hidden="true"></span>
                                    </h3>
                                </div>
                                <div class="panel-body">
                                    DETAILS DU PASSAGERS
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="panel panel-warning">
                                <div class="panel-heading">
                                    <h3 class="panel-title">4. INFOS DU PAIEMENT</h3>
                                </div>
                                <div class="panel-body">
                                    TOTAL DU PAIEMENT
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-1"></div>
    </div>

    <div class="container-fluid">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <strong>Message!</strong>Veuillez consulter les informations sur vos passagers.
                Vous ne pouvez pas modifier votre réservation une fois que vous avez procédé.
            </div>
            <div class="panel panel-default">
                <div class="panel-body">
                    <h2>
                        <center>INFOS DU PASSAGER</center>
                    </h2>
                    <div class="container-fluid">
                        <form class="form-horizontal" role="form" id="form-pass">
                            <div class="form-group">
                                <label for="">PRENOM:</label>
                                <input type="text" class="form-control" id="book-by" placeholder="Entrer votre Prenom"
                                    autofocus="" required="" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="">Contact:</label>
                                <input type="text" class="form-control" id="cont" placeholder="Entrer votre Contact"
                                    required="" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="">Adresse:</label>
                                <input type="text" class="form-control" id="address" placeholder="Enter votre Adresse"
                                    required="" autocomplete="off">
                            </div>
                            <br />
                            <?php 
						$tb = $_SESSION['totalPass'];	
					 	$count = 1;
					 	for($i = 0; $i < $tb; $i++){
					?>
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title">RÉSERVÉE(<?= $count; ?>)</h3>
                                </div>
                                <div class="panel-body">
                                    <div class="container-fluid">
                                        <div class="form-group">
                                            <label for="">NOM COMPLET (<?= $count; ?>):</label>
                                            <input type="text" class="form-control" id="fN<?php echo $i; ?>"
                                                placeholder="Entrer votre Nom Complet" required autocomplete="off">
                                        </div>

                                        <div class="form-group">
                                            <label for="">Age: (<?= $count; ?>):</label>
                                            <input type="number" class="form-control" id="age<?php echo $i; ?>"
                                                placeholder="Entrer votre age" required autocomplete="off">
                                        </div>
                                        <div class="form-group">
                                            <label for="">Genre: (<?= $count; ?>):</label>
                                            <select class="btn btn-default" id="gender<?php echo $i; ?>">
                                                <option value="Masculin">MASCULIN</option>
                                                <option value="Feminin">FEMININ</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
					$count++;
					 	}
					 ?>

                            <button type=" submit" class="btn btn-success">PRECEDENT
                                <span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span>
                            </button>

                            <button type=" submit" class="btn btn-success">SUIVANT
                                <span class="glyphicon glyphicon-arrow-right" aria-hidden="true"></span>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4"></div>
    </div>

    <?php require_once('admin/modal/message.php'); ?>

    <script type="text/javascript" src="assets/js/jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>

    <script type="text/javascript">
    $(document).on('submit', '#form-pass', function(event) {
        event.preventDefault();

        var bookBy = $('#book-by').val();
        var cont = $('#cont').val();
        var address = $('#address').val();

        var counter = <?= $i; ?>;
        for (var i = 0; i < counter; i++) {
            var fN = $('#fN' + i).val();
            var age = $('#age' + i).val();
            var gender = $('#gender' + i).val();
            $.ajax({
                url: 'data/save_booked.php',
                type: 'post',
                dataType: 'json',
                data: {
                    bookBy: bookBy,
                    cont: cont,
                    address: address,
                    fN: fN,
                    age: age,
                    gender: gender
                },
                success: function(data) {

                    if (data.valid == true) {
                        window.location = data.url;
                    }
                },
                error: function() {

                }
            });
        }
        alert('Réservé avec succès!');
    });
    </script>


</body>

</html>

<?php
}else{
	echo '<strong>';
	echo 'Page Not Exist';
	echo '</strong>';
}

 ?>