<?php 
require_once('../class/Book.php');
$books = $book->getAllBook();

 ?>

<table id="myTable-book" class="table table-bordered table-hover" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>Numero d'Identification</th>
            <th>Réservé par</th>
            <th>Contact</th>
            <th>Adresse</th>
            <th>Date de Depart</th>
            <th>
                <center>Action</center>
            </th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($books as $b): ?>
        <tr>
            <td><?= $b['book_tracker']; ?></td>
            <td><?= ucwords($b['book_by']); ?></td>
            <td><?= $b['book_contact']; ?></td>
            <td><?= ucwords($b['book_address']); ?></td>
            <td><?= $b['book_departure']; ?></td>
            <td>
                <center>
                    <button type="button" onclick="deleteBook('<?= $b['book_tracker']; ?>');"
                        class="btn btn-danger btn-xs">Annuler
                        <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
                    </button>
                    &nbsp;
                    <button type="button" onclick="viewBook('<?= $b['book_tracker']; ?>')"
                        class="btn btn-success btn-xs">Accepter le Paiement
                        <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
                    </button>
                </center>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<script type="text/javascript">
$(document).ready(function() {
    $('#myTable-book').DataTable();
});
</script>