<?php 
require_once('../class/Transaction.php');
$transactions = $transaction->getAllTransaction();

?>


<table id="myTable-trans" class="table table-bordered table-hover" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>Prenom</th>
            <th>
                <center>Age</center>
            </th>
            <th>
                <center>Genre</center>
            </th>
            <th>
                <center>Categorie de Bus</center>
            </th>
            <th>
                <center>Payé</center>
            </th>

        </tr>
    </thead>
    <tbody>
        <?php foreach($transactions as $t): ?>
        <tr>
            <td><?= ucwords($t['trans_passenger']); ?></td>
            <td align="center"><?= $t['trans_age']; ?></td>
            <td align="center"><?= $t['trans_gender']; ?></td>
            <td align="center"><?= $t['acc_type']; ?></td>
            <td align="center"><?= $t['trans_payment']; ?></td>

        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php 
$transaction->Disconnect();
 ?>

<script type="text/javascript">
$(document).ready(function() {
    $('#myTable-trans').DataTable();
});
</script>